import numpy as np
from src.config import K_EARLY, OMEGA_R, OMEGA_M, OMEGA_L, XI, LAMBDA, ETA

def uat_field_equations(a, Y):
    """
    Sistema dinamico primer orden Y=[phi, dphi/da]
    Derivado formal de S_bulk, propuesta no resultado final validado
    """
    phi, dphi_da = Y
    # Hubble normalizado E(a)^2 = H^2/H0^2
    E2 = K_EARLY * OMEGA_R * a**(-4) + K_EARLY * OMEGA_M * a**(-3) + OMEGA_L
    dE2_da = -4.0 * K_EARLY * OMEGA_R * a**(-5) - 3.0 * K_EARLY * OMEGA_M * a**(-4)
    dlnH_da = dE2_da / (2.0 * E2) if E2!=0 else 0.0
    # Coeficiente friccion P(a) y Curvatura R_norm
    P = 4.0 / a + dlnH_da
    R_norm = 6.0 * E2 * (a * dlnH_da + 2.0)
    # Ecuacion campo d2phi/da2
    V_prime = LAMBDA * phi * (phi**2 - ETA**2)
    d2phi_da2 = -P * dphi_da - (V_prime + XI * R_norm * phi) / (a**2 * E2) if a!=0 and E2!=0 else 0.0
    return [dphi_da, d2phi_da2]

def r_geom_from_kearly(k_early=K_EARLY, normalized=False):
    """
    Calcula R_geom de interferencia 8 fasores
    Delta_theta =45°*k_early
    normalized=False => 0.279182 (no normalizado) usado para coincidencia con |xi|
    normalized=True => 0.0349 matematicamente natural, rompe coincidencia
    """
    delta = np.deg2rad(45.0 * k_early)
    phasors = [np.exp(1j * n * delta) for n in range(8)]
    s = np.abs(sum(phasors))
    return s/8.0 if normalized else s
