"""
Parametros de calibracion del Marco Fenomenologico Efectivo UAT - Closure Option A Honest
Constantes derivadas de consistencia interna no validadas independientemente - ver README y docs
"""
# Background
K_EARLY = 0.967  # freno cuantico = 1 - epsilon, epsilon=0.033 overflow 3.3% = 11.76 deg ciclo 348.24 deg no 360 deg
OMEGA_R = 9.24e-5  # radiacion fijo, o 7.79398e-5 segun version
OMEGA_M = 0.3133  # materia UAT 0.30-0.315 segun doc
OMEGA_L = 1.0 - K_EARLY * (OMEGA_M + OMEGA_R)  # Lambda UAT = 1 - k_early*(Om+Or)

# Escalar-tensor
XI = -0.2810  # Acoplamiento no minimo (|xi| ~ R_geom 0.279182 dentro 0.7% pero depende definicion no normalizada, normalizado 0.0349 es 8x menor)
LAMBDA = 3.08e-112  # Acoplamiento cuartico
ETA = 4.978  # Metrica de saturacion = kappa_crit Ivancho limit 4.978, no confundir con kappa_crit informativo 1e-78 =1/N_accessible

# Anti-frecuencia
DELTA_THETA_DEG = 43.515  # =45° * k_early
R_GEOM_NON_NORM = 0.279182  # no normalizado |sum| - usado en Addenda_v9_1 para coincidencia con |xi|
R_GEOM_NORM = 0.0348977  # normalizado (1/8)|sum| - definicion matematicamente natural, 8x menor, rompe coincidencia
EPSILON_OVERFLOW = 0.033  # 3.3% = 1 - k_early = 11.76° /360°
PHI_STAR_OVER_ETA = 0.07  # 7% margen termico fluctuacion punto cero cosmologica
PHI0 = 0.456  # late-time frozen valor
PHI_STAR = 0.34846  # early branch inestable taquionico -> diverge phi=11.7 keff=-37.8 no fisico

# Vacio
PHI_GOLDEN = (1+5**0.5)/2  # 1.618
PHI_OVER_2 = 0.809017  # dimension espectral efectiva
THREE_QUARTER = 0.75  # offset termodinamico media fase heuristico
ALPHA = PHI_OVER_2 + THREE_QUARTER  # 1.559017 exponente vacio
LAMBDA_VAC = 2.50e-122  # M_Pl^4 rho_Lambda ~6.90e-27 J/m3 vs Planck 2018 6.83e-27 ~1%

# Navier-Stokes hiperviscoso - ansatz fenomenologico no derivacion rigurosa
# nu_eff(k)=nu0*(1+R_geom*L_P^2*k^2) coeficiente fijado por Lagrangiano solo si aceptas coincidencia |xi|~R_geom no normalizado
# Regularidad global hiperviscoso (-Delta)^m m>=5/4 3D teorema clasico Lions 1969 Ladyzhenskaya 1967 orden 4 suficiente
NU0 = 1.0e-6  # viscosidad base agua m2/s ejemplo
L_P = 1.616e-35  # m Planck length
K_P = 6.187e34  # 1/m
