import numpy as np
from scipy.integrate import solve_ivp
from src.dynamics import uat_field_equations, r_geom_from_kearly
from src.config import K_EARLY, XI

def run_integration(a_start=1e-4, a_end=1.0, points=1000):
    a_eval = np.logspace(np.log10(a_start), np.log10(a_end), points)
    Y0 = [1e-6, 0.0]  # Rama de-excitada inicial phi(z_rec)~0 preserva Geff~G en recombinacion rd=128.15 Mpc exacto
    sol = solve_ivp(uat_field_equations, (a_start, a_end), Y0, method='RK45', t_eval=a_eval, rtol=1e-7, atol=1e-10)
    return sol

if __name__ == "__main__":
    sol = run_integration()
    print(f"Integracion exitosa: {sol.success}")
    print(f"Valor final phi(a=1): {sol.y[0][-1]:.6f}")
    print(f"R_geom no-normalizado k_early={K_EARLY}: {r_geom_from_kearly(K_EARLY, normalized=False):.6f}")
    print(f"R_geom normalizado: {r_geom_from_kearly(K_EARLY, normalized=True):.6f}")
    print(f"|xi|={abs(XI):.6f} coincidencia 0.6% solo con no-normalizado, 8x off con normalizado")
    print("Nota: Coincidencia depende eleccion definicion, probabilidad ~6% para numeros en [0.2,0.3] al 0.6%")
