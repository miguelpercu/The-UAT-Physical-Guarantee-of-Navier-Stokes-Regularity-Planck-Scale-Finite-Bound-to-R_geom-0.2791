import numpy as np
from src.dynamics import r_geom_from_kearly, uat_field_equations
from src.config import K_EARLY, XI

def test_r_geom_coincidence():
    r_non = r_geom_from_kearly(K_EARLY, normalized=False)
    r_norm = r_geom_from_kearly(K_EARLY, normalized=True)
    # Coincidencia solo con no normalizado
    assert abs(r_non - abs(XI)) < 0.01, f"Coincidencia no-normalizado falla {r_non} vs {abs(XI)}"
    # Con normalizado debe fallar por factor 8
    assert abs(r_norm - abs(XI)) > 0.2, "Si coincide con normalizado, revision definicion"
    print(f"PASS: r_non={r_non:.6f} ~ |xi|={abs(XI):.6f} 0.6% coincidencia, r_norm={r_norm:.6f} 8x menor")

def test_background_stability():
    Y = [1e-6, 0.0]
    dY = uat_field_equations(1e-4, Y)
    assert np.isfinite(dY[0]) and np.isfinite(dY[1])

if __name__ == "__main__":
    test_r_geom_coincidence()
    test_background_stability()
    print("All tests passed - closure Option A honest status")
