# CHANGELOG HONESTO v3.0

v1.0 - 26 Oct 2025: GitHub https://github.com/miguelpercu/The_UAT_Physical_Guarantee_of_Navier_Stokes_Regularity
 - Navier_Stokes.pdf 5 pag, codigo Python con v_max sin c^2 = 1.015e47 m/s, conceptual.
 - Estado: Concepto historico, no prueba formal. Ya decia "no constituye demostracion matematica formal".

v1.1 - 6 Feb 2026: Zenodo DOI 10.5281/zenodo.18509390
 - Mismo contenido v1.0 subido a Zenodo. Concept DOI 10.5281/zenodo.18509389
 - Mantiene caracter historico.

v2.0 - 9 Sep 2026: Addenda v9.1 responding to OpenAI Sep 8 2026 blow-up claim.
 - Introdujo R_geom=0.2791 y dilema observador mosca/humano.
 - Error: presentacion como "prior art 11 meses antes" sugiere mismo resultado que OpenAI, cuando es conclusion opuesta y objeto distinto (forzado vs no forzado). Retirado en v3.0.

v2.1 - 10 Sep 2026: Zenodo DOI 10.5281/zenodo.22682586 Version 1.2
 - 10 archivos, incluye Addenda, CHANGELOG, figura tau vs V_min.
 - Todavia con lenguaje de prioridad que debe corregirse.

v3.0 - 11 Sep 2026: REPOSITORIO NUEVO HONESTO BILINGUE (este zip)
 - Autores: Miguel Angel Percudani ORCID 0009-0007-1748-3212 + Jorge Ivan Diaz co-author
 - Retira reclamo de prioridad sobre teorema OpenAI.
 - Corrige codigo: v_max = sqrt(2 rho_max c^2 / rho_fluid) = 9.66e56 m/s
 - Formaliza nu_eff(l) = nu_0 (1 + (L_P / l)^alpha) para conectar V_min con disipacion y criterio BKM.
 - Explica que cota de |v| no implica suavidad C^inf, requiere control de enstrofia.
 - Aclara que gamma=0.2375 Barbero-Immirzi es contexto LQG, no operador en ecuacion.
 - Incluye valor 8 bobinas desfasadas R_geom=0.279182 como heuristica de filtro geometrico, con advertencia no es derivado de primeros principios.
 - Reencuadre: OpenAI = mapa continuo se rompe, UAT = territorio fisico con cutoff impide realizacion.
 - Destinado a Foundations of Physics / PhilSci, no Clay submission.
